<?php
/**
 * @package  DiamondMVC
 * @author   Zyr <zyrius@live.com>
 * @version  1.0
 * @license  CC-SA 2.5 (https://creativecommons.org/licenses/by-sa/2.5/)
 * @param View $this
 */
defined('DIAMONDMVC') or die();
?>
<div class="view view-test view-temp-test">
	
</div>
