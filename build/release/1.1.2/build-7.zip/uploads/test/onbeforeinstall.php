<?php
// Clean up unused files
unlink(DIAMONDMVC_ROOT . DS . 'foo.txt');
