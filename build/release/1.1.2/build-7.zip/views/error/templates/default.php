<?php
$lang = i18n::load('diamondmvc');
?>
<div id="view-error" class="view">
	<h2><?= $lang->get('HEADING', 'ControllerError') ?></h2>
	<p><?= $lang->get('PARAGRAPH', 'ControllerError') ?></p>
</div>
