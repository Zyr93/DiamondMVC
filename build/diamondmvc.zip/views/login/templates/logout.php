<h1><em>Auf Wiedersehen!</em></h1>
<p>Sie wurden erfolgreich ausgeloggt. <a href="<?= DIAMONDMVC_URL ?>/login">Hier geht es zurück zur Login-Seite.</a></p>
